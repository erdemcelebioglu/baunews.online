<?php $__env->startSection('icerik'); ?>

    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Kullanıcı Düzenle : <?php echo e($kullanici->name); ?></h5>
                </div>



                <div class="widget-content nopadding">
                    <form method="POST" action="<?php echo e(route('kullanici.guncelle',$kullanici->id)); ?>"class="form-horizontal" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="control-group">
                            <label class="control-label">Yetki</label>
                            <div class="controls">
                                <select name="yetki" class="span11" >
                                    <?php if($kullanici->yetki == "admin"): ?>
                                        <option value="admin" selected>Admin</option>
                                        <option value="">Standart Kullanıcı</option>
                                        <?php else: ?>
                                        <option value="" selected>Standart Kullanıcı</option>
                                        <option value="admin">Admin</option>

                                    <?php endif; ?>




                                </select>
                            </div>
                        </div>

                        <div class="control-group">
                            <label class="control-label">Kullanıcı İsmi :</label>
                            <div class="controls">
                                <input id="name" type="text" class="span11" name="name" value="<?php echo e($kullanici->name); ?>" required >

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Email :</label>
                            <div class="controls">
                                <input id="email" type="email" class="span11" name="email" value="<?php echo e($kullanici->email); ?>" required>

                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Yeni Şifre</label>
                            <div class="controls">
                                <input id="password" type="password" class="span11" name="password" >

                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Tekrar Yeni Şifre</label>
                            <div class="controls">
                                <input id="password-confirm" type="password" class="span11" name="password_confirmation">
                            </div>
                        </div>

                        <div class="control-group">
                            <label class="control-label">Avatar</label>
                            <div><img border="0" src="/<?php echo e($kullanici->avatar); ?>" width="75" height="75"> </div>
                            <div class="controls">
                                <input type="file" class="span11" name="avatar">
                            </div>
                        </div>



                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">Kullanıcı Güncelle</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/kullanicilar/edit.blade.php ENDPATH**/ ?>