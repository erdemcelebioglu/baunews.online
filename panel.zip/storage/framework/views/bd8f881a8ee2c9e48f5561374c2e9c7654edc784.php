<?php $__env->startSection('icerik'); ?>
    <div class="container-fluid">
        <hr>
        <div class="row-fluid">
            <div class="span6">
                <div class="widget-box">
                    <div class="widget-title"> <span class="icon"> <i class="icon-file"></i> </span>
                        <h5>Yeni İçerikler</h5>
                    </div>
                    <div class="widget-content nopadding">
                        <ul class="recent-posts">

                            <?php $__currentLoopData = $yazilar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yazi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div class="user-thumb"> <img width="40" height="40" alt="User" src="/<?php echo e($yazi->resim); ?>"> </div>
                                <div class="article-post">
                                    <div class="fr"><a href="<?php echo e(route('yazilar.edit',$yazi->id)); ?>" class="btn btn-primary btn-mini">Düzenle</a></div>
                                    <span class="user-info"><?php echo e($yazi->kullanici->name); ?> - <?php echo date('d-m-y',strtotime($yazi->created_at)); ?> </span>
                                    <p><a href="/yazi/<?php echo e($yazi->id); ?>/<?php echo e($yazi->slug); ?>" target="_blank"><?php echo e($yazi->baslik); ?></a> </p>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <a href="<?php echo e(route('yazilar.index')); ?>" class="btn btn-warning btn-mini">Tümünü Göster</a>
                            </li>
                        </ul>
                    </div>
                </div>



            </div>
            <div class="span6">
                <div class="widget-box">
                    <div class="widget-title"> <span class="icon"><i class="icon-time"></i></span>
                        <h5>Yeni Yorumlar</h5>
                    </div>
                    <div class="widget-content nopadding">
                        <table class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>Yazan</th>
                                <th>Durum</th>
                                <th>Yorum</th>
                                <th>İşlem</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $yorumlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yorum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <td class="taskDesc"><i class="icon-info-sign"></i><?php echo e($yorum->kullanici->name); ?></td>
                                <td class="taskStatus"><span class="in-progress">
                                        <?php if($yorum->onay == 0): ?>
                                            Onay Bekliyor.
                                            <?php else: ?>
                                        Onaylanmış.
                                            <?php endif; ?>

                                    </span></td>
                                <td class="taskDesc"><?php echo str_limit(strip_tags($yorum->yorum), $limit = 100, $end = '...'); ?></td>
                                <td class="taskOptions">
                                    <?php if($yorum->onay == 1): ?>
                                    <a href="<?php echo e(route('yorum.onaykaldir',$yorum->id)); ?>" class="tip-top" data-original-title="Onay Kaldır"><i class="icon-remove"></i></a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('yorum.onayla',$yorum->id)); ?>" class="tip-top" data-original-title="Onayla"><i class="icon-ok"></i></a>

                                    <?php endif; ?>
                                   </td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>


    </div>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/index.blade.php ENDPATH**/ ?>