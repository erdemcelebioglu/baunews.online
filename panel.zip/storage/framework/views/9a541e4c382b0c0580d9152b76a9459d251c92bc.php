<?php $__env->startSection('icerik'); ?>
    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Sayfa Ekle</h5>
                </div>

                <div class="widget-content nopadding">
                    <?php echo Form::open(['route'=>'sayfalar.store','method'=>'POST','class'=>'form-horizontal']); ?>


                    <div class="control-group">
                        <label class="control-label">Sayfa Başlık</label>
                        <div class="controls">
                            <input type="text" class="span11" name="baslik"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Sayfa İçerik</label>
                        <div class="controls">
                            <textarea name="icerik" class="span11"></textarea>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Sayfa Ekle</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/admin/tinymce/tinymce.min.js"></script>
    <script>tinymce.init({selector:'textarea'});</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/sayfalar/create.blade.php ENDPATH**/ ?>