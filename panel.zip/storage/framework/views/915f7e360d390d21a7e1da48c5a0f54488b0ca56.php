<?php $__env->startSection('icerik'); ?>
    <div style="float:right;margin:15px 0 5px 0;"><a href="<?php echo e(route('yazilar.create')); ?>" class="btn btn-success">İçerik Ekle</a> </div>
    <div style="clear:both;"></div>
    <div class="widget-box">
        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>İçerik Yönetimi</h5>
        </div>
        <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
                <thead>
                <tr>
                    <th>Yazı Başlık</th>
                    <th>Kategori</th>
                    <th>Yazar</th>
                    <th width="5%">Düzenle</th>
                    <th width="5%">Sil</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $yazilar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yazi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="gradeX">
                        <td><?php echo e($yazi->baslik); ?></td>
                        <td>
                            <?php echo e($yazi->kategorisi->baslik ?? ""); ?>

                        </td>
                        <td> <?php echo e($yazi->kullanici->name ?? ""); ?></td>
                        <td class="center"><a href="<?php echo e(route('yazilar.edit',$yazi->id)); ?>"class="btn btn-success btn-mini">Düzenle</a> </td>

                        <?php echo Form::model($yazi,['route'=>['yazilar.destroy',$yazi->id],'method'=>'DELETE']); ?>

                        <td class="center">
                            <button type="submit" class="btn btn-mini btn-danger">Sil</button>
                        </td>
                        <?php echo Form::close(); ?>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>




<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/admin/css/uniform.css" />
    <link rel="stylesheet" href="/admin/css/select2.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/admin/js/excanvas.min.js"></script>
    <script src="/admin/js/jquery.min.js"></script>
    <script src="/admin/js/jquery.ui.custom.js"></script>
    <script src="/admin/js/bootstrap.min.js"></script>

    <script src="/admin/js/jquery.dataTables.min.js"></script>
    <script src="/admin/js/matrix.tables.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/yazilar/index.blade.php ENDPATH**/ ?>