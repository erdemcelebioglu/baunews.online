<?php $__env->startSection('icerik'); ?>
    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>İçerik Düzenle : <?php echo e($yazi->baslik); ?></h5>
                </div>



                <div class="widget-content nopadding">
                    <?php echo Form::model($yazi,['route'=>['yazilar.update',$yazi->id],'method'=>'PUT','class'=>'form-horizontal','files'=>'true']); ?>

                    <div class="control-group">
                        <label class="control-label">Kategori Seçin:</label>
                        <div class="controls">
                            <select name="kategori" class="span11" >
                                <option value="<?php echo e($yazi->kategori->id); ?>" selected><?php echo e($yazi->kategori->baslik); ?></option>

                                <?php $__currentLoopData = $kategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->baslik); ?></option>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">İçerik Başlık :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="baslik" value="<?php echo e($yazi->baslik); ?>"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">İçerik Açıklama :</label>
                        <div class="controls">
                            <textarea name="icerik" class="span11"><?php echo e($yazi->icerik); ?></textarea>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">Slider İçinde Göster</label>
                        <div class="controls">
                            <select name="slider" class="span11" >

                                <?php if($yazi->slider=='goster'): ?>
                                <option value="goster" selected>Göster</option>
                                <option value="gosterme">Gösterme</option>
                                    <?php else: ?>
                                    <option value="gosterme" selected>Gösterme</option>
                                    <option value="goster">Göster</option>
                                    <?php endif; ?>

                            </select>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">Mevcut Resim</label>
                        <div class="controls">
                            <img border="0" src="/<?php echo e($yazi->resim); ?>" width="150" height="150">
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">Resim Seç</label>
                        <div class="controls">
                            <input type="file" class="span11" name="resim"/>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">İçerik Video :</label>
                        <div class="controls">
                            <textarea name="video" class="span11"><?php echo e($yazi->video); ?></textarea>
                        </div>
                    </div>


                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">İçerik Kaydet</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/admin/tinymce/tinymce.min.js"></script>
    <script>tinymce.init({selector:'textarea'});</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/yazilar/edit.blade.php ENDPATH**/ ?>