<?php $__env->startSection('icerik'); ?>

    <div class="row-fluid" xmlns="http://www.w3.org/1999/html">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Site Ayarları</h5>
                </div>
                <div class="widget-content nopadding">
                    <?php echo Form::model($ayarlar,['route'=>['ayarlar.update', 1],'method'=>'PUT','files'=>'true','class'=>'form-horizontal']); ?>

                        <div class="control-group">
                            <label class="control-label">Site Başlık :</label>
                            <div class="controls">
                                <input type="text" class="span11" name="baslik" value="<?php echo e($ayarlar->baslik); ?>" />
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Site Açıklama :</label>
                            <div class="controls">
                                <input type="text" class="span11" name="aciklama" value="<?php echo e($ayarlar->aciklama); ?>" />
                            </div>
                        </div>
                    <div class="control-group">
                        <label class="control-label">Hakkımızda Kısa Açıklama</label>
                        <div class="controls">
                        <textarea class="span11" name="hakkimizda" rows="5"/><?php echo e($ayarlar->hakkimizda); ?></textarea>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Adres</label>
                        <div class="controls">
                            <textarea class="span11" name="adres" rows="5"/><?php echo e($ayarlar->adres); ?></textarea>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Telefon</label>
                        <div class="controls">
                            <input type="text"  class="span11" name="telefon" value="<?php echo e($ayarlar->telefon); ?>"  />
                        </div>
                    </div>
                        <div class="control-group">
                            <label class="control-label">E-Mail Adresi</label>
                            <div class="controls">
                                <input type="text"  class="span11" name="email" value="<?php echo e($ayarlar->email); ?>"  />
                            </div>
                        </div>
                    <div class="control-group">
                        <label class="control-label">Facebook</label>
                        <div class="controls">
                            <input type="text"  class="span11" name="facebook" value="<?php echo e($ayarlar->facebook); ?>"  />
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Twitter</label>
                        <div class="controls">
                            <input type="text"  class="span11" name="twitter" value="<?php echo e($ayarlar->twitter); ?>"  />
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Instagram</label>
                        <div class="controls">
                            <input type="text"  class="span11" name="instagram" value="<?php echo e($ayarlar->instagram); ?>"  />
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Pinterest</label>
                        <div class="controls">
                            <input type="text"  class="span11" name="pinterest" value="<?php echo e($ayarlar->pinterest); ?>"  />
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Google +</label>
                        <div class="controls">
                            <input type="text"  class="span11" name="google" value="<?php echo e($ayarlar->google); ?>"  />
                        </div>
                    </div>
                        <div class="control-group">
                            <label class="control-label">Site Logo :</label>
                            <div class="controls">
                                <input type="file" name="logo" class="span11" />
                            </div>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/ayarlar/create.blade.php ENDPATH**/ ?>