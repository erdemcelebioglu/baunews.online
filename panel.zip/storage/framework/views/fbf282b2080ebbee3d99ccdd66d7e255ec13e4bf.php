<?php $__env->startSection('icerik'); ?>
    <!-- Start Popular News [layout A+D]  -->
    <div class="zm-section bg-white ptb-70">
        <div class="container">
            <div class="row mb-40">
                <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12">
                    <div class="section-title">
                        <h2 class="h6 header-color inline-block uppercase">Popüler Haberler</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-5 col-sm-12 col-xs-12 col-lg-6">
                    <div class="zm-posts">
                        <?php if(isset($tekli)): ?>
                            <article class="zm-post-lay-a">
                                <div class="zm-post-thumb">
                                    <a href="/yazi/<?php echo e($tekli->id); ?>/<?php echo e($tekli->slug); ?>"><img src="/<?php echo e($tekli->resim); ?>" alt="img"></a>
                                </div>
                                <div class="zm-post-dis">
                                    <div class="zm-post-header">
                                        <div class="zm-category"><a href="/kategori/<?php echo e($tekli->kategori->id); ?>/<?php echo e($tekli->kategori->slug); ?>" class="bg-cat-1 cat-btn"><?php echo e($tekli->kategori->baslik); ?></a></div>
                                        <h2 class="zm-post-title h2"><a href="/yazi/<?php echo e($tekli->id); ?>/<?php echo e($tekli->slug); ?>"><?php echo e($tekli->baslik); ?></a></h2>
                                        <div class="zm-post-meta">
                                            <ul>
                                                <li class="s-meta"><?php echo e(trans('meta.yazar')); ?> : <a href="#" class="zm-author"><?php echo e($tekli->kullanici->name); ?></a></li>
                                                <li class="s-meta"><?php echo e(trans('meta.tarih')); ?> : <a href="#" class="zm-date"><?php echo date('d-m-y', strtotime($tekli->created_at)); ?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="zm-post-content">
                                        <p><?php echo e(str_limit(strip_tags($tekli->icerik), $limit=150, $end='...')); ?></p>
                                    </div>
                                </div>
                            </article>
                            <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-7 col-sm-12 col-xs-12 col-lg-6">
                    <div class="zm-posts">
                        <?php if(isset($yazilar) && count($yazilar) > 0): ?>
                        <?php $__currentLoopData = $yazilar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yazi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <article class="zm-post-lay-d clearfix">
                            <div class="zm-post-thumb f-left">
                                <a href="/yazi/<?php echo e($yazi->id); ?>/<?php echo e($yazi->slug); ?>"><img src="/<?php echo e($yazi->resim); ?>" alt="img"></a>
                            </div>
                             <div class="zm-post-dis f-right">
                                <div class="zm-post-header">
                                    <div class="zm-category"><a href="/kategori/<?php echo e($yazi->kategori->id); ?>/<?php echo e($yazi->kategori->slug); ?>" class="bg-cat-2 cat-btn"><?php echo e($yazi->kategori->baslik); ?></a></div>
                                    <h2 class="zm-post-title"><a href="/yazi/<?php echo e($yazi->id); ?>/<?php echo e($yazi->slug); ?>"><?php echo e($yazi->baslik); ?></a></h2>
                                    <div class="zm-post-meta">
                                        <ul>
                                            <li class="s-meta"><?php echo e(trans('meta.yazar')); ?> :<a href="#" class="zm-author"><?php echo e($yazi->kullanici->name); ?></a></li>
                                            <li class="s-meta"><?php echo e(trans('meta.tarih')); ?> :<a href="#" class="zm-date"><?php echo date('d-m-y', strtotime($tekli->created_at)); ?></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Start Video Post [View layout A]  -->
    <div class="video-post-area ptb-70 bg-dark">
        <div class="container">
            <div class="row mb-40">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="section-title">
                        <h2 class="h6 header-color inline-block uppercase">Videolar</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="zm-video-post-list zm-posts owl-active-3 navigator-1 clearfix">

                    <?php if(isset($videolar) && count($videolar) > 0): ?>
                        <?php $__currentLoopData = $videolar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                                <div class="zm-video-post zm-video-lay-a zm-single-post">
                                    <div class="zm-video-thumb"  data-dark-overlay="2.5" >
                                        <img src="/<?php echo e($video->resim); ?>" alt="video" width="386" height="248">
                                        <a href="/yazi/<?php echo e($video->id); ?>/<?php echo e($video->slug); ?>">
                                            <i class="fa fa-play-circle-o"></i>
                                        </a>
                                    </div>
                                    <div class="zm-video-info text-white">
                                        <h2 class="zm-post-title"><a href="/yazi/<?php echo e($video->id); ?>/<?php echo e($video->slug); ?>"><?php echo e($video->baslik); ?></a></h2>
                                        <div class="zm-post-meta">
                                            <ul>
                                                <li class="s-meta"><?php echo e(trans('meta.yazar')); ?> : <a href="#" class="zm-author"><?php echo e($video->kullanici->name); ?></a></li>
                                                <li class="s-meta"><?php echo e(trans('meta.tarih')); ?> : <a href="#" class="zm-date"><?php echo date('d-m-y', strtotime($video->created_at)); ?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
    <!-- End Video Post [View layout A]  -->
    <div class="zm-section bg-white pt-20 pb-40">
        <div class="container">
            <div class="row">
                <!-- Start left side -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8 columns">
                    <div class="row mb-40">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <div class="section-title">
                                <h2 class="h6 header-color inline-block uppercase">Yeni Haberler</h2>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="zm-posts">
                                <?php if(isset($yeniler) && count($yeniler) > 0): ?>
                                <?php $__currentLoopData = $yeniler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yeni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <article class="zm-post-lay-c zm-single-post clearfix">
                                    <div class="zm-post-thumb f-left">
                                        <a href="/yazi/<?php echo e($yeni->id); ?>/<?php echo e($yeni->slug); ?>"><img src="/<?php echo e($yeni->resim); ?>" alt="img"></a>
                                    </div>
                                    <div class="zm-post-dis f-right">
                                        <div class="zm-post-header">
                                            <div class="zm-category"><a href="/kategori/<?php echo e($yeni->kategori->id); ?>/<?php echo e($yeni->kategori->slug); ?>" class="bg-cat-<?php echo e(array_rand($renkler)); ?> cat-btn" style="color:#000000"><?php echo e($yeni->kategori->baslik); ?></a></div>
                                            <h2 class="zm-post-title"><a href="/yazi/<?php echo e($yeni->id); ?>/<?php echo e($yeni->slug); ?>"><?php echo e($yeni->baslik); ?></a></h2>
                                            <div class="zm-post-meta">
                                                <ul>
                                                    <li class="s-meta"><?php echo e(trans('meta.yazar')); ?> :<a href="#" class="zm-author"><?php echo e($yeni->kullanici->name); ?></a></li>
                                                    <li class="s-meta"><?php echo e(trans('meta.tarih')); ?> :<a href="#" class="zm-date"><?php echo date('d-m-y', strtotime($yeni->created_at)); ?></a></li>
                                                </ul>
                                            </div>
                                            <div class="zm-post-content">
                                                <p><?php echo e(str_limit(strip_tags($yeni->icerik), $limit=150, $end='...')); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>


                            </div>
                        </div>
                    </div>
                </div>
                <!-- End left side -->
                <!-- Start Right sidebar -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4 sidebar-warp columns">
                    <div class="row">

                        <!-- Start post layout E -->
                        <aside class="zm-post-lay-e-area col-xs-12 col-sm-6 col-md-6 col-lg-12 mt-60 hidden-md">
                            <div class="row mb-40">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="section-title">
                                        <h2 class="h6 header-color inline-block uppercase">En Fazla Yorum Alanlar</h2>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="zm-posts">


                                        <?php $__currentLoopData = $enfazlayorumlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yorumlar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <article class="zm-post-lay-e zm-single-post clearfix">
                                                <div class="zm-post-thumb f-left">
                                                    <a href="/yazi/<?php echo e($yorumlar->id); ?>/<?php echo e($yorumlar->slug); ?>"><img src="/<?php echo e($yorumlar->resim); ?>" alt="img" width="250" height="100"></a>
                                                </div>
                                                <div class="zm-post-dis f-right">
                                                    <div class="zm-post-header">
                                                        <h2 class="zm-post-title"><a href="/yazi/<?php echo e($yorumlar->id); ?>/<?php echo e($yorumlar->slug); ?>"><?php echo e($yorumlar->baslik); ?></a></h2>
                                                        <div class="zm-post-meta">
                                                            <ul>
                                                                <li class="s-meta"><a href="#" class="zm-author"><?php echo e($yorumlar->kullanici->name); ?></a></li>
                                                                <li class="s-meta"><a href="#" class="zm-date"><?php echo date('d-m-y', strtotime($yorumlar->created_at)); ?></a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </article>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </div>
            </aside>
            <!-- Start post layout E -->
                    </div>
                </div>
                <!-- End Right sidebar -->
            </div>

            <?php if(isset($reklam)): ?>
                <?php if($reklam->link2 != ""): ?>
                    <div class="advertisement">
                        <div class="row mt-40">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center">
                                <a href="<?php echo e($reklam->link2); ?>"><img src="<?php echo e($reklam->reklam2); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('anasayfa/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/anasayfa/index.blade.php ENDPATH**/ ?>