<?php $__env->startSection('icerik'); ?>
    <section id="page-content" class="page-wrapper">
        <div class="zm-section bg-white pt-30 xs-pt-30 pb-40">
            <div class="container">
                <div class="row">
                    <!-- Start left side -->
                    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 columns">
                        <div class="row mb-40">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="section-title">
                                    <h2 class="h6 header-color inline-block uppercase">Arama Sonuçları</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="zm-posts clearfix">


                                <?php if($sonuclar->count() <= 0): ?>
                                    <div class="col-md-12">
                                        <article class="zm-post-lay-a">

                                    Aradığınız Kelime İle Herhangi Bir İçerik Bulunamamıştır.
                                        </article></div>

                                    <?php else: ?>

                                <?php $__currentLoopData = $sonuclar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yazi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="col-md-12">
                                        <article class="zm-post-lay-a">
                                            <div class="zm-post-thumb">
                                                <a href="/yazi/<?php echo e($yazi->id); ?>/<?php echo e($yazi->slug); ?>"><img src="/<?php echo e($yazi->resim); ?>" alt="img" width="803" height="450"></a>
                                            </div>
                                            <div class="zm-post-dis">
                                                <div class="zm-post-header">
                                                    <div class="zm-category"><a href="/kategori/<?php echo e($yazi->kategori->id); ?>/<?php echo e($yazi->kategori->slug); ?>" class="bg-cat-5 cat-btn"><?php echo e($yazi->kategori->baslik); ?></a></div>
                                                    <h2 class="zm-post-title h2"><a href="/yazi/<?php echo e($yazi->id); ?>/<?php echo e($yazi->slug); ?>"><?php echo e($yazi->baslik); ?></a></h2>
                                                    <div class="zm-post-meta">
                                                        <ul>
                                                            <li class="s-meta"><a href="#" class="zm-author"><?php echo e($yazi->kullanici->name); ?></a></li>
                                                            <li class="s-meta"><a href="#" class="zm-date"><?php echo date('d-m-y', strtotime($yazi->created_at)); ?></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="zm-post-content">
                                                    <p><?php echo e(str_limit(strip_tags($yazi->icerik), $limit=150, $end='...')); ?></p>
                                                </div>
                                            </div>
                                        </article>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                            </div>
                        </div>
                    </div>
                    <!-- End left side -->
                    <!-- Start Right sidebar -->
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 sidebar-warp columns">
                        <div class="row">
                            <!-- Start post layout E -->
                            <aside class="zm-post-lay-e-area col-sm-6 col-md-12 col-lg-12 ">
                                <div class="row mb-40">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="section-title">
                                            <h2 class="h6 header-color inline-block uppercase">En Çok Yorum Alanlar</h2>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="zm-posts">

                                            <?php $__currentLoopData = $enfazlayorumlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yorumlar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <article class="zm-post-lay-e zm-single-post clearfix">
                                                    <div class="zm-post-thumb f-left">
                                                        <a href="/yazi/<?php echo e($yorumlar->id); ?>/<?php echo e($yorumlar->slug); ?>"><img src="/<?php echo e($yorumlar->resim); ?>" alt="img" width="250" height="100"></a>
                                                    </div>
                                                    <div class="zm-post-dis f-right">
                                                        <div class="zm-post-header">
                                                            <h2 class="zm-post-title"><a href="/yazi/<?php echo e($yorumlar->id); ?>/<?php echo e($yorumlar->slug); ?>"><?php echo e($yorumlar->baslik); ?></a></h2>
                                                            <div class="zm-post-meta">
                                                                <ul>
                                                                    <li class="s-meta"><a href="#" class="zm-author"><?php echo e($yorumlar->kullanici->name); ?></a></li>
                                                                    <li class="s-meta"><a href="#" class="zm-date"><?php echo date('d-m-y', strtotime($yorumlar->created_at)); ?></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </article>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </aside>
                            <!-- End post layout E -->
                            <aside class="zm-post-lay-f-area col-sm-6 col-md-12 col-lg-12 mt-70">
                                <div class="row mb-40">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="section-title">
                                            <h2 class="h6 header-color inline-block uppercase">Yeni Yorumlar</h2>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="zm-posts">

                                            <?php $__currentLoopData = $yeniyorumlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sonyorum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <div class="zm-post-lay-f zm-single-post clearfix">
                                                    <div class="zm-post-dis">
                                                        <p><?php echo e($sonyorum->kullanici->name); ?></a> - <em> <?php echo e($sonyorum->yorum); ?> </em>  <strong><a href="/yazi/<?php echo e($sonyorum->yazi->id); ?>/<?php echo e($sonyorum->yazi->slug); ?>"><?php echo e($sonyorum->yazi->baslik); ?></a></strong></p>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                    <!-- End Right sidebar -->
                </div>
                <!-- Start pagination area -->
                <div class="row hidden-xs">
                    <div class="zm-pagination-wrap mt-70">
                        <div class="container">
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">


                                    <nav class="zm-pagination ptb-40 text-center">
                                        <ul class="page-numbers">

                                            <?php echo e($sonuclar->links()); ?>


                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            
            <!-- End pagination area -->
                <!-- Start Advertisement -->
                <div class="advertisement">
                    <div class="row mt-40">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center">
                            <a href="#"><img src="images/ad/5.jpg" alt=""></a>
                        </div>
                    </div>
                </div>
                <!-- End Advertisement -->
            </div>
        </div>
    </section>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('anasayfa/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/anasayfa/arama.blade.php ENDPATH**/ ?>