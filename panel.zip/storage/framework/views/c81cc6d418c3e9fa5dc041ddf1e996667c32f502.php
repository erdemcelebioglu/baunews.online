<?php $__env->startSection('icerik'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Email Adresinizi Onaylayın.')); ?></div>

                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('Yeni bir onay linki Email adresinize gönderilmiştir.')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('Devam etmeden önce email adresinize gelen doğrulama linkini kontrol ediniz.')); ?>

                    <?php echo e(__('Eğer email almadıysanız')); ?>, <a href="<?php echo e(route('verification.resend')); ?>"><?php echo e(__('yenisini talep edebilirsiniz.')); ?></a>.
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('anasayfa.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/auth/verify.blade.php ENDPATH**/ ?>