<?php $__env->startSection('icerik'); ?>

    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>İletişim Formu</h5>
                </div>

                <div class="widget-content nopadding">
                    <form action="<?php echo e(route('iletisim.gonder')); ?>" method="POST" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>

                    <div class="control-group">
                        <label class="control-label">Ad Soyad</label>
                        <div class="controls">
                            <input type="text" class="span11" name="adsoyad"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Email Adresi</label>
                        <div class="controls">
                            <input type="text" class="span11" name="email"/>
                        </div>
                    </div>
                        <div class="control-group">
                            <label class="control-label">Mesajınız</label>
                            <div class="controls">
                                <input type="text" class="span11" name="mesaj"/>
                            </div>
                        </div>


                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Formu Gönder</button>
                    </div>
                    </form>
                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/iletisimformu.blade.php ENDPATH**/ ?>