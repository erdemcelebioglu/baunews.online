<?php $__env->startSection('icerik'); ?>

    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Yeni Kullanıcı Ekle</h5>
                </div>



                <div class="widget-content nopadding">
                    <form method="POST" action="<?php echo e(route('kullanici.kayit')); ?>"class="form-horizontal" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                    <div class="control-group">
                        <label class="control-label">Yetki</label>
                        <div class="controls">
                            <select name="yetki" class="span11" >
                                <option value="" selected>Standart Kullanıcı</option>
                                <option value="admin" >Admin</option>


                            </select>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">Kullanıcı İsmi :</label>
                        <div class="controls">
                            <input id="name" type="text" class="span11 <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Email :</label>
                        <div class="controls">
                            <input id="email" type="email" class="span11 <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                        <div class="control-group">
                            <label class="control-label">Şifre :</label>
                            <div class="controls">
                                <input id="password" type="password" class="span11 <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Tekrar Şifre:</label>
                            <div class="controls">
                                <input id="password-confirm" type="password" class="span11" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="control-group">
                            <label class="control-label">Avatar</label>
                            <div class="controls">
                                <input type="file" class="span11" name="avatar">
                            </div>
                        </div>



                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Kullanıcı Ekle</button>
                    </div>
                    </form>
                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/kullanicilar/create.blade.php ENDPATH**/ ?>