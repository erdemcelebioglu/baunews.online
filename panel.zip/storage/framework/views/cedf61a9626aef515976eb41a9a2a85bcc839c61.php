<?php echo e($slot); ?>

<?php /**PATH C:\Users\HP\panel\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>