<footer id="footer" class="footer-wrapper footer-1">
    <!-- Start footer top area -->
    <div class="footer-top-wrap ptb-70 bg-dark">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4 hidden-sm">
                    <div class="zm-widget pr-40">
                        <h2 class="h6 zm-widget-title uppercase text-white mb-30">Hakkımızda</h2>
                        <div class="zm-widget-content">
                            <p><?php echo e($ayar->hakkimizda); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-6 col-lg-2">
                    <div class="zm-widget">
                        <h2 class="h6 zm-widget-title uppercase text-white mb-30">Sosyal Medya</h2>
                        <div class="zm-widget-content">
                            <div class="zm-social-media zm-social-1">
                                <ul>
                                    <li><a href="https://www.facebook.com/<?php echo e($ayar->facebook); ?>"><i class="fa fa-facebook"></i>Facebook</a></li>
                                    <li><a href="https://twitter.com/<?php echo e($ayar->twitter); ?>"><i class="fa fa-twitter"></i>Twitter</a></li>
                                    <li><a href="https://www.pinterest.com/<?php echo e($ayar->pinterest); ?>"><i class="fa fa-pinterest"></i>Pinterest</a></li>
                                    <li><a href="https://www.instagram.com/<?php echo e($ayar->instagram); ?>"><i class="fa fa-instagram"></i>Instagram</a></li>
                                    <li><a href="https://plus.google.com/<?php echo e($ayar->google); ?>"><i class="fa fa-google-plus"></i>GooglePlus</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-6 col-lg-3">
                    <div class="zm-widget pr-50 pl-20">
                        <h2 class="h6 zm-widget-title uppercase text-white mb-30">Linkler</h2>
                        <div class="zm-widget-content">
                            <div class="zm-category-widget zm-category-1">
                                <ul>
                                    <?php $__currentLoopData = $sayfalar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sayfa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li><a href="/sayfa/<?php echo e($sayfa->id); ?>/<?php echo e($sayfa->slug); ?>"><?php echo e($sayfa->baslik); ?></a></li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-6 col-lg-3">
                    <div class="zm-widget">
                        <h2 class="h6 zm-widget-title uppercase text-white mb-30">Ücretsiz Email Aboneliği</h2>
                        <!-- Start Subscribe From -->
                        <div class="zm-widget-content">
                            <div class="subscribe-form subscribe-footer">
                                <p>Haber Bültenimize Ücretsiz Kayıt Olabilirsiniz</p>
                                <form action="<?php echo e(route('abone.ol')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="email"  name="email" placeholder="Email Adresiniz" required>
                                    <input type="submit" value="Abone Ol">
                                </form>
                            </div>
                        </div>
                        <!-- End Subscribe From -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End footer top area -->
    <div class="footer-buttom bg-black ptb-15">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                    <div class="zm-copyright">
                        <p class="uppercase">&copy; 2019 <?php echo e($ayar->baslik); ?></p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7 text-right hidden-xs">
                    <nav class="footer-menu zm-secondary-menu text-right">
                        <ul>
                            <?php $__currentLoopData = $sayfalar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sayfa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li><a href="/sayfa/<?php echo e($sayfa->id); ?>/<?php echo e($sayfa->slug); ?>"><?php echo e($sayfa->baslik); ?></a></li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\HP\panel\resources\views/anasayfa/footer.blade.php ENDPATH**/ ?>