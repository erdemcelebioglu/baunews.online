<?php $__env->startSection('icerik'); ?>

    <!-- Start page content -->
    <div id="page-content" class="page-wrapper">
        <div class="zm-section single-post-wrap bg-white ptb-70 xs-pt-30">
            <div class="container">
                <div class="row">
                    <!-- Start left side -->
                    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 columns">
                        
                        <div class="row">
                            <!-- Start single post image formate-->
                            <div class="col-md-12">
                                <article class="zm-post-lay-single">
                                    <div class="zm-post-dis">
                                        <div class="zm-post-header">
                                            <h2 class="zm-post-title h2"><?php echo e($sayfa->baslik); ?></h2>

                                        </div>
                                        <div class="zm-post-content">
                                            <?php echo $sayfa->icerik; ?>


                                        </div>
                                        <div class="entry-meta-small clearfix ptb-40 mtb-40 border-top border-bottom">
                                            <div class="meta-list pull-left">
                                                <span class="post-title">Tags</span>
                                                <a href="#">Travel</a>,<a href="#">Nature</a>,<a href="#">Environment</a>,<a href="#">Entertainment</a>
                                            </div>
                                            <div class="share-social-link pull-right">
                                                <a href="#"><i class="fa fa-facebook"></i></a>
                                                <a href="#"><i class="fa fa-twitter"></i></a>
                                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                                <a href="#"><i class="fa fa-rss"></i></a>
                                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </article>
                            </div>
                            <!-- End single post image formate -->
                        

                        </div>
                    </div>
                    <!-- End left side -->
                    <!-- Start Right sidebar -->
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 sidebar-warp columns">
                        <div class="row">
                            <!-- Start post layout E -->
                            <aside class="zm-post-lay-e-area col-sm-6 col-md-12 col-lg-12 ">
                                <div class="row mb-40">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="section-title">
                                            <h2 class="h6 header-color inline-block uppercase">En Çok Yorum Alanlar</h2>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="zm-posts">

                                            <?php $__currentLoopData = $enfazlayorumlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yorumlar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <article class="zm-post-lay-e zm-single-post clearfix">
                                                    <div class="zm-post-thumb f-left">
                                                        <a href="/yazi/<?php echo e($yorumlar->id); ?>/<?php echo e($yorumlar->slug); ?>"><img src="/<?php echo e($yorumlar->resim); ?>" alt="img" width="250" height="100"></a>
                                                    </div>
                                                    <div class="zm-post-dis f-right">
                                                        <div class="zm-post-header">
                                                            <h2 class="zm-post-title"><a href="/yazi/<?php echo e($yorumlar->id); ?>/<?php echo e($yorumlar->slug); ?>"><?php echo e($yorumlar->baslik); ?></a></h2>
                                                            <div class="zm-post-meta">
                                                                <ul>
                                                                    <li class="s-meta"><a href="#" class="zm-author"><?php echo e($yorumlar->kullanici->name); ?></a></li>
                                                                    <li class="s-meta"><a href="#" class="zm-date"><?php echo date('d-m-y', strtotime($yorumlar->created_at)); ?></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </article>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </aside>
                            <!-- End post layout E -->
                            <aside class="zm-post-lay-f-area col-sm-6 col-md-12 col-lg-12 mt-70">
                                <div class="row mb-40">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="section-title">
                                            <h2 class="h6 header-color inline-block uppercase">Yeni Yorumlar</h2>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="zm-posts">

                                            <?php $__currentLoopData = $yeniyorumlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sonyorum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <div class="zm-post-lay-f zm-single-post clearfix">
                                                    <div class="zm-post-dis">
                                                        <p><?php echo e($sonyorum->kullanici->name); ?></a> - <em> <?php echo e($sonyorum->yorum); ?> </em>  <strong><a href="/yazi/<?php echo e($sonyorum->yazi->id); ?>/<?php echo e($sonyorum->yazi->slug); ?>"><?php echo e($sonyorum->yazi->baslik); ?></a></strong></p>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                    <!-- End Right sidebar -->
                </div>
            </div>
        </div>
    </div>
    <!-- End page content -->




<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('anasayfa/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/anasayfa/sayfa.blade.php ENDPATH**/ ?>