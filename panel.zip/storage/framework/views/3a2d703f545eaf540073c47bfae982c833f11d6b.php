 <header  class="header-area header-wrapper bg-white clearfix">




        <!-- Start Sidebar Menu -->
        <div class="sidebar-menu">
            <div class="sidebar-menu-inner"></div>
            <span class="fa fa-remove"></span>
        </div>
        <!-- End Sidebar Menu -->
        <div class="header-top-bar bg-dark ptb-10">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-7  hidden-xs">
                        <div class="header-top-left">
                            <nav class="header-top-menu zm-secondary-menu">
                                <ul>
                                    <li><a href="<?php echo e(route('anasayfa')); ?>">Anasayfa</a></li>
                                    <li><a href="<?php echo e(route('iletisim.formu')); ?>">İletişim</a></li>
                                    <?php $__currentLoopData = $sayfalar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sayfa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><a href="/sayfa/<?php echo e($sayfa->id); ?>/<?php echo e($sayfa->slug); ?>"><?php echo e($sayfa->baslik); ?></a></li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-5">
                        <div class="header-top-right clierfix text-right">
                            <div class="header-social-bookmark topbar-sblock">
                                    <ul>
                                        <li><a href="https://www.facebook.com/<?php echo e($ayar->facebook); ?>"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="https://twitter.com/<?php echo e($ayar->twitter); ?>"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="https://www.instagram.com/<?php echo e($ayar->instagram); ?>"><i class="fa fa-instagram"></i></a></li>
                                        <li><a href="https://plus.google.com/<?php echo e($ayar->google); ?>"><i class="fa fa-google-plus"></i></a></li>

                                    </ul>


                            </div>




                            <div class="header-social-bookmark topbar-sblock">
                                <ul>
                                    <li><a href="<?php echo e(route('lang.switch','tr')); ?>">Türkçe</a></li>
                                    <li><a href="<?php echo e(route('lang.switch','en')); ?>">İngilizce</a></li>
                                </ul>


                            </div>

                                <?php if(!Auth::check()): ?>
                                <span class="login-btn uppercase">Giriş Yap</span> |
                                    <span class="kayit-btn uppercase"><a href="<?php echo e(route('register')); ?>"> Kayıt Ol</a></span>
                                <div class="login-form-wrap bg-white">
                                    <form method="POST" action="<?php echo e(route('login')); ?>" class="zm-signin-form text-left">
                                        <?php echo csrf_field(); ?>
                                        <input id="email" type="email" class="zm-form-control username <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email Adresiniz" required autocomplete="email">

                                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        <input id="password" type="password" class="zm-form-control password <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" placeholder="Şifreniz" required autocomplete="current-password">

                                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" class="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> &nbsp;Beni Hatırla<br>
                                        <div class="zm-submit-box clearfix  mt-20">
                                            <input type="submit" value="Giriş">
                                            <a href="<?php echo e(route('register')); ?>">Kayıt Ol</a>
                                        </div>
                                        <a href="#" class="zm-forget">Şifremi Unuttum</a>

                                    </form>
                                </div>
                                    <?php else: ?>
                                    <?php if(Auth::user()->yetki=='admin'): ?>
                                        <span class="login-btn uppercase"><a href="<?php echo e(route('yonetim.index')); ?>"> Yönetim Paneli</a></span> |
                                    <?php endif; ?>

                                    <span class="login-btn uppercase"><a href="/kullanici/">Profilim</a></span> |
                                    <span class="login-btn uppercase"><a href="<?php echo e(route('kullanici.cikis')); ?>"> Çıkış Yap</a></span>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-middle-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-lg-4 col-sm-5 col-xs-12 header-mdh">
                        <div class="global-table">
                            <div class="global-row">
                                <div class="global-cell">
                                    <div class="logo">
                                        <a href="<?php echo e(route('anasayfa')); ?>">
                                            <img  src="/<?php echo e($ayar->logo); ?>" alt="main logo">
                                        </a>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if($reklam->link1 !=""): ?>
                    <div class="col-md-8 col-lg-7 col-sm-7 col-xs-12 col-lg-offset-1 header-mdh hidden-xs">
                        <div class="global-table">
                            <div class="global-row">
                                <div class="global-cell">
                                    <div class="advertisement text-right">
                                        <a href="<?php echo e($reklam->link1); ?>" class="block"><img src="<?php echo e($reklam->reklam1); ?>" alt="ad img"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                        <?php endif; ?>


                </div>
            </div>
        </div>
        <div class="header-bottom-area hidden-sm hidden-xs">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="menu-wrapper  bg-theme clearfix">
                            <div class="row">
                                <div class="col-md-11">
                                    <button class="sidebar-menu-btn">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </button>
                                    <div class="mainmenu-area">
                                        <nav class="primary-menu uppercase">
                                            <ul class="clearfix">


                                                <?php $__currentLoopData = $kategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                                                <li class="current drop"><a href="/kategori/<?php echo e($kategori->id); ?>/<?php echo e($kategori->slug); ?>"><?php echo e($kategori->baslik); ?></a>

                                                    <?php if($kategori->altkategori->count()): ?>

                                                    <ul class="dropdown">

                                                        <?php $__currentLoopData = $kategori->altkategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altkategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><a href="/kategori/<?php echo e($altkategori->id); ?>/<?php echo e($altkategori->slug); ?>"><?php echo e($altkategori->baslik); ?></a></li>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                    </ul>

                                                        <?php endif; ?>


                                                </li>



                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <div class="search-wrap pull-right">
                                        <div class="search-btn"><i class="fa fa-search"></i></div>
                                        <div class="search-form">
                                            <form action="<?php echo e(route('arama.yap')); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="search" placeholder="Arama Yap" name="kelime">
                                                <button type="submit"><i class='fa fa-search'></i></button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </header>
<?php /**PATH C:\Users\HP\panel\resources\views/anasayfa/header.blade.php ENDPATH**/ ?>