<?php $__env->startSection('icerik'); ?>

    <div class="row-fluid" xmlns="http://www.w3.org/1999/html">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Reklam Ayarları</h5>
                </div>
                <div class="widget-content nopadding">
                    <form action="<?php echo e(route('reklam.guncelle'),1); ?>" method="POST" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

                    <div class="control-group">
                        <label class="control-label">Header Reklam Linki</label>
                        <div class="controls">
                            <input type="text" class="span11" name="link1" value="<?php echo e($reklam->link1); ?>" />
                        </div>
                    </div>
                        <div class="control-group">
                            <label class="control-label">Header Reklam Kodları</label>
                            <div class="controls">
                                <textarea class="span11" name="reklam1" rows="5"/><?php echo e($reklam->reklam1); ?></textarea>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Footer Reklam Linki</label>
                            <div class="controls">
                                <input type="text" class="span11" name="link2" value="<?php echo e($reklam->link2); ?>" />
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Footer Reklam Kodları</label>
                            <div class="controls">
                                <textarea class="span11" name="reklam2" rows="5"/><?php echo e($reklam->reklam2); ?></textarea>
                            </div>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">Kaydet</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/reklam.blade.php ENDPATH**/ ?>