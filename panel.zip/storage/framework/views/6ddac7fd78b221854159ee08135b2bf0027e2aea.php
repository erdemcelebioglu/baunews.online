<?php $__env->startSection('icerik'); ?>


    <div class="widget-box">
        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>Yorum Yönetimi</h5>
        </div>
        <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
                <thead>
                <tr>
                    <th>Yazan</th>
                    <th>Yorum</th>
                    <th>İçerik</th>
                    <th>Tarih</th>
                    <th>Durum</th>
                    <th width="5%">Düzenle</th>
                    <th width="5%">Sil</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $yorumlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yorum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="gradeX">
                        <td><?php echo e($yorum->kullanici->name); ?></td>
                        <td>
                            <?php echo str_limit(strip_tags($yorum->yorum),$limit=100,$end='...'); ?>

                        </td>
                        <td> <?php echo e($yorum->yazi->baslik); ?></td>
                        <td> <?php echo date('d-m-y',strtotime($yorum->created_at)); ?></td>

                        <td>
                            <?php if($yorum->onay == 0): ?>
                                Onaysız
                                <a href="<?php echo e(route('yorum.onayla',$yorum->id)); ?>"class="btn btn-success btn-mini">Onayla</a>
                                <?php else: ?>
                                Onaylı
                                <a href="<?php echo e(route('yorum.onaykaldir',$yorum->id)); ?>"class="btn btn-danger btn-mini">Onay Kaldır</a>
                            <?php endif; ?>
                        </td>
                        <td class="center"><a href="<?php echo e(route('yorumlar.edit',$yorum->id)); ?>"class="btn btn-success btn-mini">Düzenle</a> </td>

                        <?php echo Form::model($yorum,['route'=>['yorumlar.destroy',$yorum->id],'method'=>'DELETE']); ?>

                        <td class="center">
                            <button type="submit" class="btn btn-mini btn-danger">Sil</button>
                        </td>
                        <?php echo Form::close(); ?>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>




<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/admin/css/uniform.css" />
    <link rel="stylesheet" href="/admin/css/select2.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/admin/js/excanvas.min.js"></script>
    <script src="/admin/js/jquery.min.js"></script>
    <script src="/admin/js/jquery.ui.custom.js"></script>
    <script src="/admin/js/bootstrap.min.js"></script>

    <script src="/admin/js/jquery.dataTables.min.js"></script>
    <script src="/admin/js/matrix.tables.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/yorumlar/index.blade.php ENDPATH**/ ?>