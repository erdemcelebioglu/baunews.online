<?php $__env->startSection('icerik'); ?>

    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Çeviri Düzenle : <?php echo e($kelime->key); ?></h5>
                </div>

                <div class="widget-content nopadding">
                    <?php echo Form::model($kelime,(['route'=>['ceviri.update',$kelime->id],'method'=>'PUT','class'=>'form-horizontal'])); ?>



                    <div class="control-group">
                        <label class="control-label">Grup (Türkçe Karakter Kullanmıyoruz)</label>
                        <div class="controls">
                            <input type="text" class="span11" name="group" value="<?php echo e($kelime->group); ?>" required/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Kelime (Türkçe Karakter Kullanmıyoruz)</label>
                        <div class="controls">
                            <input type="text" class="span11" name="key" value="<?php echo e($kelime->key); ?>" required/>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">Türkçesi</label>
                        <div class="controls">
                            <input type="text" class="span11" name="tr" value="<?php echo e($turkce); ?>" required/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">İngilizcesi</label>
                        <div class="controls">
                            <input type="text" class="span11" name="en" value="<?php echo e($ingilizce); ?>" required/>
                        </div>
                    </div>




                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Güncelle</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="/admin/tinymce/tinymce.min.js"></script>
    <script>tinymce.init({ selector:'textarea' });</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/ceviri/edit.blade.php ENDPATH**/ ?>