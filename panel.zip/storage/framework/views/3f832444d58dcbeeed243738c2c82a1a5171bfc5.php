<?php $__env->startSection('icerik'); ?>
    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Sayfa Düzenle <?php echo e($sayfa->baslik); ?></h5>
                </div>

                <div class="widget-content nopadding">
                    <?php echo Form::model($sayfa,(['route'=>['sayfalar.update',$sayfa->id],'method'=>'PUT','class'=>'form-horizontal'])); ?>


                    <div class="control-group">
                        <label class="control-label">Sayfa Başlık</label>
                        <div class="controls">
                            <input type="text" class="span11" name="baslik" value="<?php echo e($sayfa->baslik); ?>"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Sayfa İçerik</label>
                        <div class="controls">
                            <textarea name="icerik" class="span11"><?php echo $sayfa->icerik; ?></textarea>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Sayfa Güncelle</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/admin/tinymce/tinymce.min.js"></script>
    <script>tinymce.init({selector:'textarea'});</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/sayfalar/edit.blade.php ENDPATH**/ ?>