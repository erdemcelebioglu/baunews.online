<?php $__env->startSection('icerik'); ?>

    <!-- Start page content -->
    <div id="page-content" class="page-wrapper">
        <div class="zm-section single-post-wrap bg-white ptb-70 xs-pt-30">
            <div class="container">
                <div class="row">
                    <!-- Start left side -->
                    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 columns">
                        
                        <div class="row">
                            <!-- Start single post image formate-->
                            <div class="col-md-12">
                                <article class="zm-post-lay-single">


                                    <?php if($yazi->video != ""): ?>

                                        <div class="zm-post-video">
                                            <div class="embed-responsive-16by9 embed-responsive">
                                                <iframe src="<?php echo e(strip_tags($yazi->video)); ?>" class="embed-responsive-item" ></iframe>
                                            </div>
                                        </div>

                                    <?php else: ?>

                                    <div class="zm-post-thumb">
                                        <img src="/<?php echo e($yazi->resim); ?>" alt="img">
                                    </div>

                                    <?php endif; ?>

                                    <div class="zm-post-dis">
                                        <div class="zm-post-header">
                                            <h2 class="zm-post-title h2"><?php echo e($yazi->baslik); ?></h2>
                                            <div class="zm-post-meta">
                                                <ul>
                                                    <li class="s-meta"><a href="#" class="zm-author"><?php echo e($yazi->kullanici->name); ?></a></li>
                                                    <li class="s-meta"><a href="#" class="zm-date"><?php echo date('d-m-y', strtotime($yazi->created_at)); ?></a></li>

                                                </ul>
                                            </div>
                                        </div>
                                        <div class="zm-post-content">
                                            <?php echo $yazi->icerik; ?>


                                        </div>
                                        <div class="entry-meta-small clearfix ptb-0 mtb-40 border-top ">


                                        </div>
                                        
                                    </div>
                                </article>
                            </div>
                            <!-- End single post image formate -->
                        
                        <!--Start Similar post -->
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <aside class="zm-post-lay-a2-area">
                                    <div class="post-title mb-40">
                                        <h2 class="h6 inline-block">Benzer İçerikler</h2>
                                    </div>
                                    <div class="row">
                                        <div class="zm-posts clearfix">

                                            <?php $__currentLoopData = $ilgililer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ilgili): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                    <article class="zm-post-lay-a2">
                                                        <div class="zm-post-thumb">
                                                            <a href="/yazi/<?php echo e($ilgili->id); ?>/<?php echo e($ilgili->slug); ?>"><img src="/<?php echo e($ilgili->resim); ?>" alt="img" width="350" height="150"></a>
                                                        </div>
                                                        <div class="zm-post-dis">
                                                            <div class="zm-post-header">
                                                                <h2 class="zm-post-title h2"><a href="/yazi/<?php echo e($ilgili->id); ?>/<?php echo e($ilgili->slug); ?>"><?php echo e($ilgili->baslik); ?></a></h2>
                                                                <div class="zm-post-meta">
                                                                    <ul>
                                                                        <li class="s-meta"><a href="#" class="zm-author"><?php echo e($ilgili->kullanici->name); ?></a></li>
                                                                        <li class="s-meta"><a href="#" class="zm-date"><?php echo date('d-m-y', strtotime($ilgili->created_at)); ?></a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </article>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </div>
                                    </div>
                                </aside>
                            </div>
                            <!-- End similar post -->
                            <!-- Start Comment box  -->
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="review-area mt-50 ptb-70 border-top">
                                    <div class="post-title mb-5">
                                        <h2 class="h6 inline-block">Toplam Yorum Sayısı: <?php echo e($yazi->yorumlar->count()); ?></h2>
                                    </div>
                                    <div class="post-title mb-40">
                                        <h2 class="h6 inline-block">Toplam Değerlendirme: <?php echo e($yazi->yorumlar->count()); ?></h2>

                                        <p> <h2 class="h6 inline-block">Ortalama Değerlendirme Puanı: <?php echo e(round($yazi->averageRating,1)); ?> <?php for($i=1;$i<=$yazi->ratingPercent(100);$i++): ?>
                                               <i class="fa fa-star" aria-hidden="true"></i>
                                        <?php endfor; ?> </h2>
                                        </p>
                                    </div>
                                    <div class="review-wrap">
                                        <div class="review-inner">

                                            <?php $__currentLoopData = $yorumlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yorum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                                            <div class="single-review clearfix">
                                                <div class="reviewer-img">
                                                    <img src="/<?php echo e($yorum->kullanici->avatar); ?>" alt="" width="125" height="75">
                                                </div>
                                                <div class="reviewer-info">
                                                    <h4 class="reviewer-name"><a href="#"><?php echo e($yorum->kullanici->name); ?></a></h4>
                                                    <span class="date-time"><?php echo date('d-m-y', strtotime($yorum->created_at)); ?></span>
                                                    <p class="reviewer-comment"><?php echo e($yorum->yorum); ?></p>
                                                    <p> <?php echo e($yorum->rating); ?>

                                                        <?php for($i=1;$i<=$yorum->rating;$i++): ?>
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                            <?php endfor; ?> </p>



                                                </div>
                                            </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Comment box  -->
                            <?php if(Auth::check()): ?>
                            <!-- Start comment form -->
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="comment-form-area">
                                    <div class="post-title mb-40">
                                        <h2 class="h6 inline-block">Yorum Yaz</h2>
                                    </div>
                                    <div class="form-wrap">
                                        <form action="<?php echo e(route('yorum.gonder')); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="form-inner clearfix">
                                                <div class="single-input">
                                                    <input type="hidden" value="<?php echo e($yazi->id); ?>" name="yazi">
                                                    <div class="post-title mb-40">
                                                        <h2 class="h6 inline-block">Değerlendirme</h2>
                                                        <input id="input-id" type="text" class="rating" data-size="sm" name="derece">
                                                    </div>


                                                    <textarea class="textarea" name="yorum" placeholder="Yorumunuzu Yazın..."></textarea>
                                                </div>
                                                <button class="submit-button" type="submit">Gönder</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php else: ?>
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        Yorum Yapabilmek İçin <a href="<?php echo e(route('login')); ?>">Giriş Yapın</a> veya <a href="<?php echo e(route('register')); ?>">Kayıt Olun</a>
                                    </div>



                                <?php endif; ?>
                            <!-- End comment form -->
                        </div>
                    </div>
                    <!-- End left side -->
                    <!-- Start Right sidebar -->
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 sidebar-warp columns">
                        <div class="row">
                            <!-- Start post layout E -->
                            <aside class="zm-post-lay-e-area col-sm-6 col-md-12 col-lg-12 ">
                                <div class="row mb-40">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="section-title">
                                            <h2 class="h6 header-color inline-block uppercase">En Çok Yorum Alanlar</h2>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="zm-posts">

                                            <?php $__currentLoopData = $enfazlayorumlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yorumlar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <article class="zm-post-lay-e zm-single-post clearfix">
                                                <div class="zm-post-thumb f-left">
                                                    <a href="/yazi/<?php echo e($yorumlar->id); ?>/<?php echo e($yorumlar->slug); ?>"><img src="/<?php echo e($yorumlar->resim); ?>" alt="img" width="250" height="100"></a>
                                                </div>
                                                <div class="zm-post-dis f-right">
                                                    <div class="zm-post-header">
                                                        <h2 class="zm-post-title"><a href="/yazi/<?php echo e($yorumlar->id); ?>/<?php echo e($yorumlar->slug); ?>"><?php echo e($yorumlar->baslik); ?></a></h2>
                                                        <div class="zm-post-meta">
                                                            <ul>
                                                                <li class="s-meta"><a href="#" class="zm-author"><?php echo e($yorumlar->kullanici->name); ?></a></li>
                                                                <li class="s-meta"><a href="#" class="zm-date"><?php echo date('d-m-y', strtotime($yorumlar->created_at)); ?></a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </article>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </aside>
                            <!-- End post layout E -->
                            <aside class="zm-post-lay-f-area col-sm-6 col-md-12 col-lg-12 mt-70">
                                <div class="row mb-40">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="section-title">
                                            <h2 class="h6 header-color inline-block uppercase">Yeni Yorumlar</h2>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="zm-posts">

                                            <?php $__currentLoopData = $yeniyorumlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sonyorum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <div class="zm-post-lay-f zm-single-post clearfix">
                                                <div class="zm-post-dis">
                                                    <p><?php echo e($sonyorum->kullanici->name); ?></a> - <em> <?php echo e($sonyorum->yorum); ?> </em>  <strong><a href="/yazi/<?php echo e($sonyorum->yazi->id); ?>/<?php echo e($sonyorum->yazi->slug); ?>"><?php echo e($sonyorum->yazi->baslik); ?></a></strong></p>
                                                </div>
                                            </div>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                    <!-- End Right sidebar -->
                </div>
            </div>
        </div>
    </div>
    <!-- End page content -->




<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<script>
    // initialize with defaults
    $("#input-id").rating();

    // with plugin options (do not attach the CSS class "rating" to your input if using this approach)
    $("#input-id").rating({'size':'sm'});


</script>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('anasayfa/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/anasayfa/detay.blade.php ENDPATH**/ ?>