<?php $__env->startSection('icerik'); ?>
    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Çeviri Ekle</h5>
                </div>

                <div class="widget-content nopadding">
                    <?php echo Form::open(['route'=>'ceviri.store','method'=>'POST','class'=>'form-horizontal']); ?>


                    <div class="control-group">
                        <label class="control-label">Kelime Grubu (Türkçe Karakter kullanılmıyor)</label>
                        <div class="controls">
                            <input type="text" class="span11" name="group" required/>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">Kelime (Türkçe Karakter kullanılmıyor) </label>
                        <div class="controls">
                            <input type="text" class="span11" name="key" required/>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">Türkçe Çeviri</label>
                        <div class="controls">
                            <input type="text" class="span11" name="tr" required/>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">İngilizce Çeviri</label>
                        <div class="controls">
                            <input type="text" class="span11" name="en" required/>
                        </div>
                    </div>


                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Ekle</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/admin/tinymce/tinymce.min.js"></script>
    <script>tinymce.init({selector:'textarea'});</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/ceviri/create.blade.php ENDPATH**/ ?>