<?php $__env->startSection('icerik'); ?>

    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Kategori Düzenleme : <?php echo e($kategori->baslik); ?></h5>
                </div>

                <div class="widget-content nopadding">
                    <form action="<?php echo e(route('kategoriler.update',$kategori->id)); ?>" method="PUT" class="form-horizontal" onsubmit="return ajaxekle();" id="ajax-form">
                        <?php echo e(csrf_field()); ?>

                        <div class="control-group">
                            <label class="control-label">Üst Kategori</label>
                            <div class="controls">
                                <select name="ust_id" class="span11">
                                    <option value="">Ana Kategori Yap</option>
                                    <?php $__currentLoopData = $tumkategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tumkategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($tumkategori->id); ?>" <?php echo e($tumkategori->id == old('ust_id',$kategori->ust_id) ? 'selected' : ''); ?>><?php echo e($tumkategori->baslik); ?></option>


                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </select>
                            </div>
                        </div>

                        <div class="control-group">
                            <label class="control-label">Kategori Başlık</label>
                            <div class="controls">
                                <input type="text" class="span11" name="baslik" value="<?php echo e($kategori->baslik); ?>"/>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Site Açıklama</label>
                            <div class="controls">
                                <input type="text" class="span11" name="aciklama" value="<?php echo e($kategori->aciklama); ?>"/>
                            </div>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">Kategori Düzenle</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>



        function ajaxekle() {
            var form = $("#ajax-form");

            var form_data = $("#ajax-form").serialize();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });

            $.ajax({

                type:"PUT",
                url:"<?php echo e(route('kategoriler.update',$kategori->id)); ?>",
                data : form_data,
                success: function() {
                    swal.fire({
                        title: "Kategori Güncellendi",
                        text: "Lütfen Bekleyin...",
                        type:"success",
                        timer: 2000,
                        showConfirmButton: false
                    });

                }
            });

            return false;
        }
    </script>

    <script src="https://code.jquery.com/jquery.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/kategoriler/edit.blade.php ENDPATH**/ ?>