 <!-- Start trending post area -->
    <div class="trending-post-area">
        <div class="container-fluid">
            <div class="row">
                <div class="trend-post-list zm-posts owl-active-1 clearfix">
                    <!-- Start single trend post -->


                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <div class="col-2">
                        <article class="zm-trending-post zm-lay-a zm-single-post" data-dark-overlay="2.5"  data-scrim-bottom="9" data-effict-zoom="3">
                            <div class="zm-post-thumb">
                                <img src="/<?php echo e($slider->resim); ?>" alt="img">
                            </div>
                            <div class="zm-post-dis text-white">
                                <div class="zm-category"><a href="/kategori/<?php echo e($slider->kategorisi->id); ?>/<?php echo e($slider->kategorisi->slug); ?>" class="bg-cat-3 cat-btn"><?php echo e($slider->kategorisi->baslik); ?></a></div>
                                <h2 class="zm-post-title"><a href="/yazi/<?php echo e($slider->id); ?>/<?php echo e($slider->slug); ?>"><?php echo e($slider->baslik); ?></a></h2>
                                <div class="zm-post-meta">
                                    <ul>
                                        <li class="s-meta"><a href="#" class="zm-author"><?php echo e($slider->kullanici->name); ?></a></li>
                                        <li class="s-meta"><a href="#" class="zm-date"><?php echo date('d-m-y',strtotime($slider->created_at)); ?></a></li>
                                    </ul>
                                </div>
                            </div>
                        </article>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>

<?php /**PATH C:\Users\HP\panel\resources\views/anasayfa/slider.blade.php ENDPATH**/ ?>