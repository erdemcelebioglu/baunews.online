<div class="breakingnews-wrapper hidden-xs">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                <div class="breakingnews clearfix fix">
                    <div class="bn-title">
                        <h7 class="uppercase">Yeni Haberler</h7>
                    </div>
                    <div class="news-wrap">
                        <ul class="bkn clearfix" id="bkn">

                            <?php $__currentLoopData = $yeniler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yeni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="/yazi/<?php echo e($yeni->id); ?>/<?php echo e($yeni->slug); ?>"><?php echo e($yeni->baslik); ?></a> </li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</header>
<?php /**PATH C:\Users\HP\panel\resources\views/anasayfa/flash.blade.php ENDPATH**/ ?>