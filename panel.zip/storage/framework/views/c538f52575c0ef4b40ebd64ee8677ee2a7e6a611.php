<?php $__env->startSection('icerik'); ?>
    <div style="float:right;margin:15px 0 5px 0;"><a href="<?php echo e(route('kullanici.ekle')); ?>" class="btn btn-success">Kullanıcı Ekle</a> </div>
    <div style="clear:both;"></div>
    <div class="widget-box">
        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>Kullanıcı Yönetimi</h5>
        </div>
        <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
                <thead>
                <tr>
                    <th>Kullanıcı Adı</th>
                    <th>Kullanıcı Email</th>
                    <th>Kullanıcı Yetki</th>
                    <th>Düzenle</th>
                    <th>Sil</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $kullanicilar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kullanici): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="gradeX">
                        <td><?php echo e($kullanici->name); ?></td>

                        <td> <?php echo e($kullanici->email); ?></td>
                        <td>
                            <?php if($kullanici->yetki == 'admin'): ?>

                                Admin

                               <?php else: ?>

                                Standart Kullanıcı

                            <?php endif; ?>

                        </td>
                        <td class="center"><a href="<?php echo e(route('kullanici.duzenle',$kullanici->id)); ?>"class="btn btn-success btn-mini">Düzenle</a> </td>

                        <form action="<?php echo e(route('kullanici.sil',$kullanici->id)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                        <td class="center">
                            <button type="submit" class="btn btn-mini btn-danger">Sil</button>
                        </td>
                        </form>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>




<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/admin/css/uniform.css" />
    <link rel="stylesheet" href="/admin/css/select2.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/admin/js/excanvas.min.js"></script>
    <script src="/admin/js/jquery.min.js"></script>
    <script src="/admin/js/jquery.ui.custom.js"></script>
    <script src="/admin/js/bootstrap.min.js"></script>

    <script src="/admin/js/jquery.dataTables.min.js"></script>
    <script src="/admin/js/matrix.tables.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\panel\resources\views/admin/kullanicilar/index.blade.php ENDPATH**/ ?>