<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reklam extends Model
{
    protected $table='reklamlar';
    protected $guarded = [];
}
